
//This is also a testing file!

enum test {
    test,
    ing,
    one,
    two,
    three,
    exclamation_mark = "!"
}

//blah blah blah